
<?php $__env->startSection('title', $search_term); ?>
<?php $__env->startSection('content'); ?>
    <h1 class="text-3xl font-bold mb-6"><?php echo app('translator')->get('Résultats pour'); ?> : "<?php echo e($search_term); ?>"</h1>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if (isset($component)) { $__componentOriginal62596a3184e87855cb7c15fc2b35a01f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62596a3184e87855cb7c15fc2b35a01f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cards.card_actor','data' => ['actor' => $actor]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cards.card_actor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['actor' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($actor)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62596a3184e87855cb7c15fc2b35a01f)): ?>
<?php $attributes = $__attributesOriginal62596a3184e87855cb7c15fc2b35a01f; ?>
<?php unset($__attributesOriginal62596a3184e87855cb7c15fc2b35a01f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62596a3184e87855cb7c15fc2b35a01f)): ?>
<?php $component = $__componentOriginal62596a3184e87855cb7c15fc2b35a01f; ?>
<?php unset($__componentOriginal62596a3184e87855cb7c15fc2b35a01f); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-600"><?php echo app('translator')->get('Aucun résultat trouvé'); ?></p>
        <?php endif; ?>
    </div>

    <?php if($total_pages > 1): ?>
        <div class="mt-8 flex justify-center space-x-2">
            <?php for($i = 1; $i <= min($total_pages, 5); $i++): ?>
                <a href="<?php echo e(route('actor.search', ['name' => $search_term, 'page' => $i])); ?>"
                    class="px-4 py-2 <?php echo e($current_page == $i ? 'bg-blue-600 text-white' : 'bg-white'); ?> rounded-lg shadow">
                    <?php echo e($i); ?>

                </a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Studying\4eme_s2\projet tuteuré\try\1\gitg\projtutorfilmrecom\movierex\resources\views/actor-search.blade.php ENDPATH**/ ?>