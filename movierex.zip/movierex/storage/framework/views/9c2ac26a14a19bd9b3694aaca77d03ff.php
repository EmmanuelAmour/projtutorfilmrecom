<aside class="w-64 fixed left-0 top-0 h-screen bg-gray-800 shadow-xl z-50 transition-all duration-300" id="sidebar">
    <div class="flex flex-col h-full p-6">
        <!-- En-tête -->
        <div class="text-amber-400 font-bold text-xl mb-8 flex items-center">
            <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
            </svg>
            MovieRex
        </div>

        <!-- Filtres -->
        <nav class="space-y-4 flex-1 overflow-y-auto">
            <div class="filter-group">
                <button class="filter-item" data-filter="genre">
                    <span class="icon">🎬</span>
                    Genres
                    <i class="dropdown-icon ml-auto transition-transform" data-target="genre"></i>
                </button>
                <div class="submenu hidden" id="genre-submenu">
                    <!-- Sous-éléments générés par JS -->
                </div>
            </div>

            <div class="filter-item" data-filter="year">
                <span class="icon">📅</span>
                Année
                <input type="number" class="year-input hidden" min="1900" max="2025">
            </div>
        </nav>

        <!-- Mode sombre -->
        <div class="mt-auto pt-6 border-t border-gray-700">
            <button id="theme-toggle" class="filter-item">
                <span class="icon">🌓</span>
                Mode sombre
            </button>
        </div>
    </div>
</aside>

<style>
    .filter-item {
        @apply w-full flex items-center p-3 rounded-lg hover:bg-gray-700 transition-colors text-gray-300;
    }

    .submenu {
        @apply pl-11 pt-2 space-y-2;
    }

    .year-input {
        @apply ml-2 w-20 px-2 py-1 bg-gray-700 rounded text-white;
    }
</style>

<script>
    // Gestion des sous-menus
    document.querySelectorAll('.filter-group button').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.dataset.filter;
            const submenu = document.getElementById(`${target}-submenu`);
            const icon = btn.querySelector('.dropdown-icon');

            submenu.classList.toggle('hidden');
            icon.classList.toggle('rotate-180');

            // Génération dynamique du contenu
            if (!submenu.dataset.loaded) {
                const items = {
                    genre: ['Action', 'Comédie', 'Drame', 'SF', 'Horreur'],
                    year: Array.from({
                        length: 10
                    }, (_, i) => 2025 - i)
                };

                submenu.innerHTML = items[target]
                    .map(item => `<div class="filter-item">${item}</div>`)
                    .join('');

                submenu.dataset.loaded = true;
            }
        });
    });

    // Toggle du thème
    document.getElementById('theme-toggle').addEventListener('click', () => {
        document.documentElement.classList.toggle('dark');
    });
</script>
<?php /**PATH C:\Studying\4eme_s2\projet tuteuré\try\1\gitg\projtutorfilmrecom\movierex\resources\views/components/aside.blade.php ENDPATH**/ ?>