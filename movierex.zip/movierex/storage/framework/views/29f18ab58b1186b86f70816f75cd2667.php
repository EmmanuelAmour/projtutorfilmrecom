<?php $__env->startSection('title', 'Accueil'); ?>
<?php $__env->startSection('content'); ?>
    <div class="mb-12 text-center">
        <h1 class="text-4xl font-bold mb-4">Bienvenue sur MovieRex</h1>
        <p class="text-gray-400 max-w-2xl mx-auto">Votre destination ultime pour explorer le monde du cinéma</p>
    </div>

    <!-- Section Populaire -->
    <section>
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold">Populaire</h2> <!-- Correction orthographique -->
            <div class="flex space-x-2">
                <button onclick="scrollCarousel(-1)"
                    class="p-2 rounded-full bg-gray-800 hover:bg-amber-400 transition-colors">←</button>
                <button onclick="scrollCarousel(1)"
                    class="p-2 rounded-full bg-gray-800 hover:bg-amber-400 transition-colors">→</button>
            </div>
        </div>
        <div class="movie-carousel flex overflow-x-auto pb-4 gap-4 scroll-smooth scrollbar-hide" style="height: auto;">
            <?php $__currentLoopData = $popular_movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-64 flex-shrink-0 h-96"> <!-- Hauteur fixe -->
                    <?php if (isset($component)) { $__componentOriginal7162a419da04a01404281e9819dfa8a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7162a419da04a01404281e9819dfa8a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cards.card_movie','data' => ['movie' => $movie,'index' => $index]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cards.card_movie'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['movie' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movie),'index' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($index)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7162a419da04a01404281e9819dfa8a3)): ?>
<?php $attributes = $__attributesOriginal7162a419da04a01404281e9819dfa8a3; ?>
<?php unset($__attributesOriginal7162a419da04a01404281e9819dfa8a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7162a419da04a01404281e9819dfa8a3)): ?>
<?php $component = $__componentOriginal7162a419da04a01404281e9819dfa8a3; ?>
<?php unset($__componentOriginal7162a419da04a01404281e9819dfa8a3); ?>
<?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php if (isset($component)) { $__componentOriginal55e035a8a6b7a8a938f0e8bc8d50e19e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal55e035a8a6b7a8a938f0e8bc8d50e19e = $attributes; } ?>
<?php $component = App\View\Components\Throw1::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('throw1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Throw1::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal55e035a8a6b7a8a938f0e8bc8d50e19e)): ?>
<?php $attributes = $__attributesOriginal55e035a8a6b7a8a938f0e8bc8d50e19e; ?>
<?php unset($__attributesOriginal55e035a8a6b7a8a938f0e8bc8d50e19e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal55e035a8a6b7a8a938f0e8bc8d50e19e)): ?>
<?php $component = $__componentOriginal55e035a8a6b7a8a938f0e8bc8d50e19e; ?>
<?php unset($__componentOriginal55e035a8a6b7a8a938f0e8bc8d50e19e); ?>
<?php endif; ?>

    <!-- Sections catégories - Grille uniforme -->
    <div class="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        <?php $__currentLoopData = ['Western', 'Action', 'Drame']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Exemple de boucle -->
            <section>
                <h2 class="text-xl font-bold mb-4 border-l-4 border-amber-400 pl-3"><?php echo e($genre); ?></h2>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <?php $__currentLoopData = $keyword_movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="group relative h-full flex flex-col"> <!-- Flex pour gestion hauteur -->
                            <div class="grow relative overflow-hidden rounded-lg">
                                <img src="https://image.tmdb.org/t/p/w500/<?php echo e($movie['poster_path']); ?>"
                                    alt="<?php echo e($movie['title']); ?>"
                                    class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                                    loading="lazy">
                                <div class="absolute inset-0 bg-gradient-to-t from-gray-900/90 to-transparent"></div>
                                <div class="absolute bottom-0 left-0 right-0 p-3 space-y-1">
                                    <span class="text-sm font-medium text-white line-clamp-1"><?php echo e($movie['title']); ?></span>
                                    <div class="flex items-center space-x-2 text-amber-400 text-xs">
                                        <i class="fas fa-star"></i>
                                        <span><?php echo e($movie['vote_average']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <script>
        function scrollCarousel(direction) {
            const carousel = document.querySelector('.movie-carousel');
            const scrollAmount = carousel.offsetWidth * A * direction;
            carousel.scrollBy({
                left: scrollAmount,
                behavior: 'smooth'
            });
        }
    </script>

    <style>
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }

        .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
    </style>


    <!-- Répéter le même pattern pour les autres catégories -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Studying\4eme_s2\projet tuteuré\try\1\gitg\projtutorfilmrecom\movierex\resources\views/home.blade.php ENDPATH**/ ?>