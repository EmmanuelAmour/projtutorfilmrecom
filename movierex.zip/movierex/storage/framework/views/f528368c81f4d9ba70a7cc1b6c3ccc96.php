<?php $__env->startSection('title', 'Popular Movies'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-12 text-center">
        <h1 class="text-4xl font-bold mb-4">Popular movies</h1>
    </div>
    <div class="container mx-auto px-4 py-8">
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal7162a419da04a01404281e9819dfa8a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7162a419da04a01404281e9819dfa8a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cards.card_movie','data' => ['movie' => $movie,'index' => $index]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cards.card_movie'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['movie' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movie),'index' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($index)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7162a419da04a01404281e9819dfa8a3)): ?>
<?php $attributes = $__attributesOriginal7162a419da04a01404281e9819dfa8a3; ?>
<?php unset($__attributesOriginal7162a419da04a01404281e9819dfa8a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7162a419da04a01404281e9819dfa8a3)): ?>
<?php $component = $__componentOriginal7162a419da04a01404281e9819dfa8a3; ?>
<?php unset($__componentOriginal7162a419da04a01404281e9819dfa8a3); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Studying\4eme_s2\projet tuteuré\try\1\gitg\projtutorfilmrecom\movierex\resources\views/popular.blade.php ENDPATH**/ ?>