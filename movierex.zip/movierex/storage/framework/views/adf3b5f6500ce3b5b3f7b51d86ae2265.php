<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Welcome to MovieRex</h1>
        <p>Your one-stop destination for all things movies!</p>

    </div>
    <section>
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold">Popluar</h2>
            <div class="flex space-x-2">
                <button class="carousel-nav p-2 rounded-full bg-gray-800 hover:bg-amber-400">←</button>
                <button class="carousel-nav p-2 rounded-full bg-gray-800 hover:bg-amber-400">→</button>
            </div>
        </div>
        <div class="movie-carousel flex overflow-x-auto pb-4 space-x-4 scroll-smooth">

            <!-- Utilisation de la classe "movie-card" pour chaque film -->
            <?php $__currentLoopData = $popular_movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal7162a419da04a01404281e9819dfa8a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7162a419da04a01404281e9819dfa8a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cards.card_movie','data' => ['movie' => $movie,'index' => $index]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cards.card_movie'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['movie' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movie),'index' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($index)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7162a419da04a01404281e9819dfa8a3)): ?>
<?php $attributes = $__attributesOriginal7162a419da04a01404281e9819dfa8a3; ?>
<?php unset($__attributesOriginal7162a419da04a01404281e9819dfa8a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7162a419da04a01404281e9819dfa8a3)): ?>
<?php $component = $__componentOriginal7162a419da04a01404281e9819dfa8a3; ?>
<?php unset($__componentOriginal7162a419da04a01404281e9819dfa8a3); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <!-- Sections par catégorie -->
    <div class="grid gap-8 md:grid-cols-2">
        <section>
            <h2 class="text-xl font-bold mb-4 border-l-4 border-amber-400 pl-3">Western</h2>
            <div class="grid grid-cols-2 gap-4">
                <?php $__currentLoopData = $keyword_movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-gray-800 rounded-lg overflow-hidden genre-pill">
                        <img src="https://image.tmdb.org/t/p/w200_and_h300_bestv2/<?php echo e($movie['poster_path']); ?>"
                            class="w-full h-48 object-cover" loading="lazy">
                        <div class="p-2 text-center">
                            <span class="text-sm"><?php echo e($movie['title']); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <section>
            <h2 class="text-xl font-bold mb-4 border-l-4 border-amber-400 pl-3">Horreur</h2>
            <div class="grid grid-cols-2 gap-4">
                <?php $__currentLoopData = $horror_movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div
                        class="bg-gray-800 rounded-lg overflow-hidden genre-pill hover:border-amber-400 border-transparent border-2">
                        <img src="https://image.tmdb.org/t/p/w200_and_h300_bestv2/<?php echo e($movie['poster_path']); ?>"
                            class="w-full h-48 object-cover brightness-75 hover:brightness-100 transition">
                        <div class="p-2 text-center text-sm">
                            <?php echo e($movie['title']); ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Studying\4_eme_annee_S2\projet tuteuré\try\1\laravel-movie-app\movierex\resources\views/home.blade.php ENDPATH**/ ?>