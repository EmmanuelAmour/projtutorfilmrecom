<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($actor['name']); ?></title>
    <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/png">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .animate-detail {
            animation: fadeIn 0.6s ease-out forwards;
        }
    </style>
</head>

<body class="bg-gray-50">
    <?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60 = $attributes; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Header::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $attributes = $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>

    <div class="min-h-screen bg-gray-900">
        <!-- Backdrop -->
        <div class="fixed inset-0 -z-10 opacity-25">
            <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/60 to-gray-900/20"></div>
            <?php if($actor['profile_path']): ?>
                <img src="https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/<?php echo e($actor['profile_path']); ?>"
                    alt="<?php echo e($actor['name']); ?>" class="object-cover w-full h-full">
            <?php endif; ?>
        </div>

        <!-- Main Content -->
        <div class="container px-4 mx-auto pt-24 animate-detail">
            <div class="flex flex-col lg:flex-row gap-8 backdrop-blur-sm bg-white/90 rounded-2xl shadow-2xl p-8">
                <!-- Profile Section -->
                <div class="flex-shrink-0 w-full lg:w-96">
                    <div class="relative group">
                        <img src="https://image.tmdb.org/t/p/w600_and_h900_bestv2/<?php echo e($actor['profile_path']); ?>"
                            alt="<?php echo e($actor['name']); ?>"
                            class="rounded-xl ring-1 ring-black/10 transition-transform duration-300 group-hover:scale-105"
                            loading="eager">
                    </div>

                    <!-- Personal Info -->
                    <div class="mt-6 space-y-3 text-gray-700">
                        <div class="flex items-center space-x-2">
                            <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                            <span><?php echo e(\Carbon\Carbon::parse($actor['birthday'])->age); ?> ans</span>
                        </div>

                        <?php if($actor['place_of_birth']): ?>
                            <div class="flex items-center space-x-2">
                                <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                </svg>
                                <span><?php echo e($actor['place_of_birth']); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Details Section -->
                <div class="flex-grow space-y-6 text-gray-700">
                    <h1 class="text-4xl font-bold text-gray-900"><?php echo e($actor['name']); ?></h1>

                    <!-- Biography -->
                    <div class="space-y-4">
                        <h2 class="text-2xl font-semibold text-gray-900">Biographie</h2>
                        <p class="text-gray-600 leading-relaxed bg-white/50 p-4 rounded-xl">
                            <?php echo e($actor['biography'] ?? 'Aucune biographie disponible'); ?>

                        </p>
                    </div>

                    <!-- Filmographie -->
                    <div class="space-y-4">
                        <h2 class="text-2xl font-semibold text-gray-900">Filmographie</h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('movies.show', $movie['id'])); ?>" class="group">
                                    <div class="bg-white rounded-xl p-4 hover:shadow-lg transition-shadow">
                                        <div class="flex gap-4">
                                            <img src="https://image.tmdb.org/t/p/w200/<?php echo e($movie['poster_path']); ?>"
                                                alt="<?php echo e($movie['title']); ?>" class="w-24 h-32 object-cover rounded-lg">
                                            <div>
                                                <h3 class="font-semibold group-hover:text-blue-600">
                                                    <?php echo e($movie['title']); ?></h3>
                                                <p class="text-sm text-gray-500"><?php echo e($movie['character']); ?></p>
                                                <p class="text-sm text-gray-400 mt-2">
                                                    <?php echo e($movie['release_date'] ? \Carbon\Carbon::parse($movie['release_date'])->format('Y') : 'Date inconnue'); ?>

                                                </p>
                                            </div>
                                        </div>
                                        <?php if($movie['overview']): ?>
                                            <p class="text-sm text-gray-500 mt-2 line-clamp-2"><?php echo e($movie['overview']); ?>

                                            </p>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Studying\4eme_s2\projet tuteuré\try\1\laravel-movie-app\movierex\resources\views/actor.blade.php ENDPATH**/ ?>